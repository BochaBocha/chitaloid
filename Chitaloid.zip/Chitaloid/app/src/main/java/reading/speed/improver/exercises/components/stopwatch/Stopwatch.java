package reading.speed.improver.exercises.components.stopwatch;

public class Stopwatch {
}
