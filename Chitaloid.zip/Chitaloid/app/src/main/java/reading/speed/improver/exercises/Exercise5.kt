package com.example.trofi.course_work.exercises

class Exercise5 : GeneralExercise() {

    override fun displaySettingsDialog() {
        super.displaySettingsDialog()
    }
}