package com.example.trofi.course_work.exercises.Exercise1

import com.example.trofi.course_work.exercises.GeneralExercise

class Exercise1 : GeneralExercise()

