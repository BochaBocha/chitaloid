package reading.speed.improver.ui;

import android.support.v4.app.Fragment;
import androidx.lifecycle.ViewModelProviders;
import reading.speed.improver.model.ExerciseModel;
public class ExerciseSettingsFragment extends Fragment {

//    public void onStart() {
//        ExerciseModel userModel = ViewModelProviders.of(getActivity()).get(ExerciseModel.class);
//    }
}
