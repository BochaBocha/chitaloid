package reading.speed.improver.exercises.components.timer;

public class Timer {
}
