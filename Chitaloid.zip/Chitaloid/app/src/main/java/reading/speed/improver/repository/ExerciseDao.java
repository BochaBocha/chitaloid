package reading.speed.improver.repository;

public class ExerciseDao {
}
