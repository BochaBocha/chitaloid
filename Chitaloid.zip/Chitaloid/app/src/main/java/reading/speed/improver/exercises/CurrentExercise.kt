package reading.speed.improver.exercises

object CurrentExercise {
    var textSizeCoef = 1
}